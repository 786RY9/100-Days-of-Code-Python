from turtle import Screen, Turtle
import time
from snake import Snake # Assuming snake is defined elsewhere
from food import Food # Assuming food is defined elsewhere
from scoreboard import ScoreBoard # Assuming scoreboard is defined elsewhere


screen = Screen()
screen.setup(width=600,height=600)
screen.bgcolor('black')
screen.title('Snake Game')
screen.tracer(0)

snake = Snake()
food = Food(screen) # Pass the screen object to Food
scoreboard = ScoreBoard()
screen.listen()

screen.onkey(fun=snake.up,key='Up')
screen.onkey(fun=snake.down,key='Down')
screen.onkey(fun=snake.right,key='Right')
screen.onkey(fun=snake.left,key='Left')
game_is_on = True

while game_is_on:
    screen.update()
    time.sleep(0.08)
    snake.move()
        
    # detect collision with food
    if snake.head.distance(food) < 15:
        
        
        scoreboard.increment_score() # Increment score BEFORE the check
        
        # Check if the score is a multiple of 4
        if scoreboard.score % 4 == 0:
            food.big_circle()
        else:
            # If not a multiple of 4, revert to simple circle if a big one was active
            if food.is_big_circle_active:
                food.simple_circle()
            else:
                # Regular refresh if it wasn't a special food
                food.refresh()
                
            
        scoreboard.current_score()
        snake.extend()

    # Detect collison with wall.
    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        game_is_on = False
        scoreboard.game_over() 


    # Detect collision with any segment in the tail
    for segment in snake.segments[1:]:
        if snake.head.distance(segment) < 10:
            game_is_on=False
            scoreboard.game_over()
    
    
screen.exitonclick()