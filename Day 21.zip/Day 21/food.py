from turtle import Turtle, Screen
import random
    
# Food Class Level Constants
MAX_RADIUS = 4.0 # Shape size multiplier for max big circle size
MIN_RADIUS = 0.5 # Shape size multiplier for min simple circle size/big circle min size
GROWTH_STEP = 0.5 # How much the radius changes per animation frame
ANIMATION_SPEED = 50 # Milliseconds between animation updates (lower is faster)
BIG_CIRCLE_DURATION = 8000 # Milliseconds for the big circle to be active

class Food(Turtle):
    
    def __init__(self, screen): # Pass screen to Food
        super().__init__()
        self.screen = screen # Store screen reference
        self.current_radius = MIN_RADIUS
        self.increasing = True # Flag to control growth direction
        self.is_big_circle_active = False
        self.simple_circle()
    
    
    def simple_circle(self):
        # Stop any pending animation and timeout
        self.is_big_circle_active = False
        self.screen.ontimer(lambda: None, 1) # This is a trick to cancel pending timers (though not guaranteed)
        
        self.shape('circle')
        self.shapesize(stretch_wid=MIN_RADIUS, stretch_len=MIN_RADIUS)
        self.color('blue')
        self.penup()
        self.speed('fastest')
        self.refresh()
    
    def refresh(self):
        random_x = random.randint(-280, 280)
        random_y = random.randint(-280, 280)
        self.goto(random_x, random_y)

    def animate_circle(self):
        if not self.is_big_circle_active:
            # Stop animating if the 8-second period is over
            return

        # Animate size change
        self.shapesize(stretch_len=self.current_radius, stretch_wid=self.current_radius)

        if self.increasing:
            self.current_radius += GROWTH_STEP
        else:
            self.current_radius -= GROWTH_STEP

        # Reverse growth direction at limits
        if self.current_radius >= MAX_RADIUS:
            self.increasing = False
        elif self.current_radius <= MIN_RADIUS + GROWTH_STEP: # Check just above min to allow it to shrink
            self.increasing = True
            
        # Schedule the next animation frame
        self.screen.ontimer(self.animate_circle, ANIMATION_SPEED)

    def big_circle(self):
        # Set state to big circle
        self.is_big_circle_active = True
        self.current_radius = MAX_RADIUS # Start big
        self.color('red')
        
        # Move to a new random position
        random_x = random.randint(-280, 280)
        random_y = random.randint(-280, 280)
        self.goto(random_x, random_y)
        
        # Start the size animation
        self.animate_circle()
        
        # Schedule the simple_circle to be called after 8 seconds
        self.screen.ontimer(self.simple_circle, BIG_CIRCLE_DURATION)